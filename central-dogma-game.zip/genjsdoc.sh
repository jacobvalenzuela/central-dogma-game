#!/bin/bash
jsdoc -r -d jsdoc .
